import requests
from bs4 import BeautifulSoup

lien = 'https://www.dominos.fr/la-carte/nos-pizzas'
contournement_restriction = {'User-Agent': 'Mozilla/5.0'}
carte_domino = requests.get(lien, headers=contournement_restriction)


soup = BeautifulSoup(carte_domino.text, 'html.parser')
#print(soup)

pizzas = []
noms_pizzas = soup.find_all('span', class_='menu-entry')

for pizza in noms_pizzas:
    pizzas.append(pizza.text.strip())

for pizza_nom in pizzas:
    print(pizza_nom)

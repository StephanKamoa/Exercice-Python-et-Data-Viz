import requests
from bs4 import BeautifulSoup

lien = 'https://www.dominos.fr/la-carte-pizza/bacon-groovy-pbcg'
lien2 = 'https://www.dominos.fr/la-carte-pizza/pepperoni-party-pppa'
contournement_restriction = {'User-Agent': 'Mozilla/5.0'}
bacon_groovy = requests.get(lien, headers=contournement_restriction)
pepperoni_party = requests.get(lien2, headers=contournement_restriction)

# Bacon Groovy
soup1 = BeautifulSoup(bacon_groovy.text, 'html.parser')
print(soup1)

ingredient_bacon_groovy = soup1.find('p', itemprop='description').text

print("Les ingrédients et le nombre de kilo calories (pour 100gr) de la pizza Bacon Groovy en taille medium classique :")

print("Les ingrédients :\n", ingredient_bacon_groovy)

print('Le nombre de kilo calories :')

calorie_bacon_groovy = soup1.find('li', id='size-Taille Medium Classique').find('a')['onclick'].split(', ')[1]
print(calorie_bacon_groovy)

# Pepperoni Party Pizza
soup2 = BeautifulSoup(pepperoni_party.text, 'html.parser')
print(soup2)

ingredient_pepperoni_party = soup2.find('p', itemprop='description').text

print("Les ingrédients et le nombre de kilo calories (pour 100gr) de la pizza Pepperoni Party:")

print("Les ingrédients :\n",ingredient_pepperoni_party)

print('Le nombre de kilo calories :')
calorie_pepperoni_party = soup2.find('li', id='size-Taille Medium Classique').find('a')['onclick'].split(', ')[1]

print(calorie_pepperoni_party)

# Comparaison :

calorie_pepperoni_int = int(''.join(filter(str.isdigit, calorie_pepperoni_party)))
calorie_bacon_int = int(''.join(filter(str.isdigit, calorie_bacon_groovy)))

if calorie_bacon_int < calorie_pepperoni_int:
    print("La pizza Bacon Groovy est la moins calorique.")
elif calorie_bacon_int > calorie_pepperoni_int:
    print("La pizza Pepperoni Party est la moins calorique.")
else:
    print("Les deux pizzas ont le même nombre de calories.")
